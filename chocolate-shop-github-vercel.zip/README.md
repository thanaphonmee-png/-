# Cocoa Craft Chocolate Shop
Static landing page demo with two SKUs and cart.

## Deploy to Vercel
Import this GitHub repository into Vercel. No build command is needed for this static HTML project.

## Note
Checkout is demo-only and is not connected to Google Sheets yet. Avoid entering real customer data.
